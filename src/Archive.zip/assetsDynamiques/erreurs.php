<?php
header('Content-Type: image/svg+xml');
?>
<svg id="Calque_1" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 558.48 558.48">
    <defs>
        <style>
            .cls-1 {
                fill: none;
                stroke: #<?php echo $_GET['fgColor'] ?>;
                stroke-miterlimit: 10;
                stroke-width: 25px;
            }
        </style>
    </defs>
    <path class="cls-1"
        d="M387.25,16.81H177.36a13.37,13.37,0,0,0-9.46,3.92L19.49,169.14a13.39,13.39,0,0,0-3.92,9.46V388.49A13.4,13.4,0,0,0,19.49,398L167.9,546.37a13.37,13.37,0,0,0,9.46,3.92H387.25a13.37,13.37,0,0,0,9.46-3.92L545.13,398a13.4,13.4,0,0,0,3.92-9.47V178.6a13.39,13.39,0,0,0-3.92-9.46L396.71,20.73A13.37,13.37,0,0,0,387.25,16.81Z"
        transform="translate(-3.07 -4.31)" />
    <path class="cls-1"
        d="M315.94,366.52h-66.3a12.87,12.87,0,0,1-12.82-11.77l-24-280a12.87,12.87,0,0,1,12.82-14H338.12A12.87,12.87,0,0,1,351,74.67l-22.18,280A12.87,12.87,0,0,1,315.94,366.52Z"
        transform="translate(-3.07 -4.31)" />
    <rect class="cls-1" x="239.26" y="398.21" width="81" height="72" rx="15.3" />
</svg>