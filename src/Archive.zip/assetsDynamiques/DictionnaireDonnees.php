<?php
header('Content-Type: image/svg+xml');

echo '<svg id="Calque_1" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 401 575.43"><defs><style>.cls-1{fill:none;stroke:#' . $_GET['fgColor'] . ';stroke-miterlimit:10;stroke-width:20px;}.cls-2{isolation:isolate;font-size:409.84px;fill:#' . $_GET['fgColor'] . ';font-family:SnellRoundhand-Bold, Snell Roundhand;font-weight:700;}</style></defs><path class="cls-1" d="M352,75.3V525.9H248v.1H49v13.3a29,29,0,0,0,29,29H391V75.3Z" transform="translate(0 -2.87)"/><path class="cls-1" d="M39,525.2a29,29,0,0,1-29-29V61.2a29,29,0,0,1,29-29H352v493H39" transform="translate(0 -2.87)"/><text class="cls-2" transform="translate(70.75 352.87) scale(0.92 1)">x</text></svg>'
    ?>