<?php
header('Content-Type: image/svg+xml');
?>
<svg id="Calque_1" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 308.62 477.67">
    <defs>
        <style>
            .cls-1 {
                fill: #<?php echo $_GET['fgColor'] ?>;
                stroke-width: 10px;
            }
        </style>
    </defs>
    <polygon class="cls-1" points="0 0 0 337.41 292.2 168.7 0 0" />
    <rect class="cls-1" x="254.5" y="267.2" width="87" height="239" transform="translate(-240.23 166.54) rotate(-30)" />
</svg>