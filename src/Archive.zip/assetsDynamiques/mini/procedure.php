<?php
header('Content-Type: image/svg+xml');
?>
<svg id="Calque_1" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 571.17 328.77">
    <defs>
        <style>
            .cls-1 {
                fill: none;
                stroke: #<?php echo $_GET['fgColor'] ?>;
                stroke-miterlimit: 10;
                stroke-width: 25px;
            }
        </style>
    </defs>
    <rect class="cls-1" x="5" y="5" width="561.17" height="318.32" rx="22.77" />
    <rect class="cls-1" x="50.12" y="5.45" width="471.04" height="318.32" rx="14.65" />
</svg>