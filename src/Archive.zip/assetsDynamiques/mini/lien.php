<?php
header('Content-Type: image/svg+xml');
?>
<svg id="Calque_1" data-name="Calque 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 451 477">
    <defs>
        <style>
            .cls-1 {
                fill: none;
                stroke: #<?php echo $_GET['fgColor'] ?>;
                stroke-linecap: round;
                stroke-miterlimit: 10;
                stroke-width: 20px;
            }
        </style>
    </defs>
    <line class="cls-1" x1="441" y1="10" x2="10" y2="467" />
</svg>